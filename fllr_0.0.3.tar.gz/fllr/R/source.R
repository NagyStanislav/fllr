#############################################################################################################
# Functional local linear regression (fllr) including data-driven basis (functional predictor's FPCA)
# and automatic choice of:
#  * dimension J of the approximating subspace
#  * bandwidth for regression operator
#  * bandwidth for the functional derivative
#############################################################################################################

#' Functional local linear regression
#'
#' Functional local linear regression (fllr) with automatic bandwidth selection
#' including data-driven basis
#' (functional predictor's FPCA).
#'
#' @param Responses vector of scalar responses
#' @param LEARN     matrix of regressors, functional values evaluated at common domain,
#' one function per row
#' @param PRED      matrix of functions at which new values are predicted, one function
#' per row
#' @param nboot     number of wild bootstrap replicates used for finding the bandwidth
#' for functional derivatives
#' @param kNN.grid.length  grid length for the bandwidth search
#' @param percent   if \code{BASIS} is not given, percentage of explained sample
#' variance that is taken into account when building the basis expansion in terms of
#' eigenfunctions of the empirical covariance operator
#' @param boot.seed random seed for the bootstrap procedure
#' @param BASIS     if basis functions are not estimated using the empirical covariance
#' operator, matrix of basis functions. One function per row.
#' @param method    bandwidth selection method for the regression operator. Possible values
#' are \code{cv} for leave-one-out cross-validation, and \code{aicc} for the improved
#' Akaike information criterion
#' @param derivative logical; should also the bandwidth for the functional derivative
#' should be searched for? If set to \code{FALSE}, the bandwidth for the regression
#' operator is used also for the functional derivatives.
#' @param J.est      logical; should it be cross-validated also with respect to the
#' dimension of the basis? If set to \code{FALSE}, the number of functions in
#' \code{BASIS} is taken to be the optimal dimension. Ignored if \code{BASIS = NULL}.
#'
#' @return A list with the following components:
#' \itemize{
#' \item \code{Estimated.responses} A vector of responses estimated by the local linear
#' method that correspond to the functions in the rows of \code{LEARN}.
#' \item \code{ESTIMATED.DERIV} A matrix of the estimated (Riesz representations of)
#' functional derivatives of the regression operator, each row corresponding to a row
#' of \code{LEARN}.
#' \item \code{Predicted.responses} If matrices \code{LEARN} and \code{PRED} differ,
#' a vector of predicted responses, each element of the vector corresponding to a row
#' of \code{PRED}.
#' \item \code{PREDICTED.DERIV} If matrices \code{LEARN} and \code{PRED} differ,
#' a matrix of predicted (Riesz representations of) functional derivatives,
#' each row corresponding to a row of \code{PRED}.
#' \item \code{mse} Minimum criterion value (mean squared error for \code{method = cv}
#' or AICc for \code{method = aicc}) obtained in the search for the optimal bandwidth
#' for the regression operator.
#' \item \code{knn.opt} List of optimal bandwidths for the regression operator \code{reg}
#' and the functional derivative \code{deriv}.
#' \item \code{dim.opt} Optimal basis dimension used for both the regression operator and
#' the functional derivative.
#' }
#'
#' @examples
#' gridsize = 101                           # grid size
#' Grid = seq(0, 1, length = gridsize)      # grid of measurements
#' nlearn = 150                             # learning sample size
#' ntest = 150                              # testing sample size
#' sample.size = nlearn + ntest             # whole sample size
#' Jmodel = 4                               # number of basis elements used for building functional predictors
#' BASIS = phif(Jmodel, Grid)               # first Jmodel Fourier basis elements
#' UNIF = matrix(runif(sample.size * Jmodel, min = -1, max = 1), nrow = sample.size, ncol = Jmodel)
#' PREDICTORS = UNIF %*% BASIS[1:Jmodel, ]
#'
#' ##########################################
#' # Simulate the regression and functional derivative
#' ##########################################
#' TRANSFORMED.REG = exp(- UNIF^2)
#' TRANSFORMED.DERIV = - 2 * UNIF * TRANSFORMED.REG
#' Regression = apply(TRANSFORMED.REG, 1, sum)
#' DERIV = TRANSFORMED.DERIV %*% BASIS[1:Jmodel,]
#'
#' ###########################################
#' # Simulate scalar responses ("Responses")
#' ###########################################
#' error = rnorm(sample.size, sd = 1)
#' Responses.fullsample = Regression + error
#'
#' ###########################################
#' # Build learning sample
#' ###########################################
#' LEARN = PREDICTORS[1:nlearn, ]
#' PRED = PREDICTORS[-(1:nlearn), ]
#' Responses = Responses.fullsample[1:nlearn]
#'
#' res = fllr(Responses, LEARN, PRED)
#'
#' plot(res$Predicted.responses~Regression[-(1:nlearn)])
#'

fllr = function(Responses, LEARN, PRED, nboot = 100, kNN.grid.length = 30, percent = 0.95,
                boot.seed = NULL, BASIS = NULL, method = "cv", derivative = TRUE, J.est = TRUE)
  #############################################################################################################
# The "fllr" routine estimates the Functional Local Linear Regression as well as its functional derivative.
# "fllr" computes a data-driven basis (functional predictor's FPCA) and selects the best dimension of the
# approximating subspace. Two specific bandwidths are automatically chosen: one for estimating the regression
# operator and one for the functional derivative.
# The "fllr" arguments are:
# "Responses" vector containing the observed responses for learning
# "LEARN" matrix containing the observed functional predictors (row by row) for learning
# "PRED" matrix containing the observed functional predictors for predicting purpose
# "nboot" integer indicating the number of repetitions used in the wild bootstrap procedure carrying out
#         the bandwidth for estimating the functional derivative (100 by default)
# "kNN.grid.length" integer controlling the grid size of nearest neighbors used for determining local
#           bandwidths.
# "percent" percentage of explained variance in the functional principal component analysis of the predictors ;
#           the maximum size of the approximating subspace expresses at least "percent" of the
#           remaining total variance once the first (largest) eigenvalue of the covariance operator is dropped.
# "BASIS"   the basis of functions onto which to project - a matrix with basis functions in rows
#           if BASIS is not provided (by default), the eigenbasis of the data is used
# Returns a list:
#############################################################################################################
{
  # Check whether there are additional observations for predicting corresponding responses
  outsample = T
  if(identical(LEARN,PRED)) outsample = F
  ## if LEARN is the same matrix as PRED, outsample = F and PRED = LEARN
  ##
  # Estimate the second order moment operator
  gridsize = ncol(LEARN)
  if(is.null(BASIS)){
    if(outsample){
      sample.size = nrow(LEARN) + nrow(PRED)
      COV = crossprod(rbind(LEARN, PRED)) / (sample.size * (gridsize - 1))
    }else{
      sample.size = nrow(LEARN)
      COV = crossprod(LEARN) / (sample.size * (gridsize - 1))
    }
  }
  # Install the r package "parallelDist" to use "parDist" and compute
  # distances ||X_i - X_j||^2 between functional predictors
  require(parallelDist)
  require(fllr)
  DIST = as.matrix(parDist(LEARN, method = "euclidean")) / sqrt(gridsize - 1)
  DIST.SORTED.ROW.BY.ROW = t(apply(DIST, 1, sort))
  if(is.null(BASIS)){
    # Compute estimated first "dim.max" eigenfunctions
    res.eig = eigen(COV, sym = T)
    # Drop first eigenvalue and derive the approximating subspace expressing at least "percent"
    # of the remaining total variance
    cum.part.of.variance = cumsum(res.eig$values[-1]) / sum(res.eig$values[-1])
    dim.min = 1
    dim.max = sum(cum.part.of.variance < percent) + 2
    BASIS = t(res.eig$vectors[, 1:dim.max]) * sqrt(gridsize - 1)
  } else {
    # if J is estimated, dimensions are searched from one
    if(J.est) dim.min = 1 else dim.min = nrow(BASIS)
    dim.max = nrow(BASIS)
  }
  nlearn = nrow(LEARN)
  rank.min = kNN.grid.length
  Knn.learn.ratio = c(0.02, 0.25, 0.5, 0.75, 0.9)
  # Build an adaptative grid of kNN (number of knearest neighbours used for determining local bandwidths)
  # If the minimum of the criterion ("CRIT.REG") is reached for the bandwidth corresponding to
  # "Knn.grid[kNN.grid.length]", then the grid "Knn.grid" is updated
  for(ratio in 1:(length(Knn.learn.ratio) - 1)){
    knn.min = max(round(nlearn * Knn.learn.ratio[ratio]), dim.max + 4)
    knn.max = round(nlearn * Knn.learn.ratio[ratio + 1])
    knn.range = knn.max - knn.min
    if(knn.range <= kNN.grid.length){
      Knn.grid = knn.min:knn.max
    }else{
      step = ceiling(knn.range / kNN.grid.length)
      Knn.grid = seq(from = knn.min, to = knn.max, by = step)
    }
    kNN.grid.length = length(Knn.grid)
    rank.min = kNN.grid.length
    #########################################################################################
    # estimate regression operator with bandwidth maximizing cross validation criterion
    #########################################################################################
    CRIT.REG = matrix(Inf, kNN.grid.length, dim.max)
    dim.max = nrow(BASIS)
    B = BASIS[1:dim.max,]
    INNER.LEARN = tcrossprod(LEARN, B) / (gridsize - 1)
    if(method=="cv"){
      H = matrix(nrow=nrow(INNER.LEARN),ncol=length(Knn.grid))
      for(knni in 1:length(Knn.grid)) H[,knni] = DIST.SORTED.ROW.BY.ROW[, Knn.grid[knni] + 1]
      for(dim in dim.min:dim.max){
        CRIT.REG[,dim] = llsm_cv_single(matrix(INNER.LEARN[,1:dim],ncol=dim),DIST,Responses,H=H,kernel="Epanechnikov")$CV[,dim+1]
        dim.opt = dim
        if(dim >= 2){
          if(min(CRIT.REG[, dim - 1]) < min(CRIT.REG[, dim])){
            dim.opt = dim - 1
            break
          }
        }
      }
    }
    if(method=="aicc"){
      for(dim in (dim.min:dim.max)){
        # compute inner products between functional predictors and basis functions
        if(dim==1){
          B = as.matrix(t(BASIS[1, ]))
        }else{
          B = BASIS[1:dim, ]
        }
        INNER.LEARN = tcrossprod(LEARN, B) / (gridsize - 1)
        Estimated.responses = 0
        count = 0
        for(knn in Knn.grid){
          count = count + 1
          trHatMat = 0
          for(ii in 1:nlearn){
            PHI = cbind(1, t(t(INNER.LEARN) - INNER.LEARN[ii, ]))
            bwd = DIST.SORTED.ROW.BY.ROW[ii, knn + 1]
            U = DIST[ii, 1:nlearn] / bwd
            Kernel = (1 - U^2) * (U < 1)
            PHIK = PHI * Kernel
            TEMP = crossprod(PHIK, PHI)
            TEMP.INV = solve(TEMP)
            Temp = crossprod(PHIK, Responses)
            Estimated.responses[ii] = crossprod(TEMP.INV[1, ], Temp)
            # Compute the trace of the hat matrix for the AICc criterion
            trHatMat = trHatMat + crossprod(TEMP.INV[1, ], t(PHIK)[, ii])
          }
          # Compute criterion for selecting the optimal bandwidth
          Estimated.errors = Estimated.responses - Responses
          CRIT.REG[count, dim] = mean(Estimated.errors^2)
          CRIT.REG[count, dim] = log(CRIT.REG[count, dim]) + 1 + (2 * trHatMat + 2)/(nlearn - trHatMat - 2)
        }
        dim.opt = dim
        if(dim >= 2){
          if(min(CRIT.REG[, dim - 1]) < min(CRIT.REG[, dim])){
            dim.opt = dim - 1
            break
          }
        }
      }
    }
    if(rank.min != order(CRIT.REG[, dim.opt])[1]) break
  }
  # Determine corresponding criterion value for the regression
  mse = min(CRIT.REG[, dim.opt])
  # Determine optimal number of k-nearest neighbours and dimension J for the regression
  knn.reg = (Knn.grid)[order(CRIT.REG[, dim.opt])[1]]
  # Compute inner products between functional predictors and basis functions
  B = matrix(BASIS[1:dim.opt,],nrow=dim.opt)
  INNER.LEARN = matrix(INNER.LEARN[,1:dim.opt],ncol=dim.opt)
  if(method=="cv") Estimated.responses = llsm_leave(INNER.LEARN,INNER.LEARN,DIST,Responses,h = DIST.SORTED.ROW.BY.ROW[, knn.reg + 1], kernel="Epanechnikov")[,1]
  if(method=="aicc") Estimated.responses = llsm(INNER.LEARN,INNER.LEARN,DIST,Responses,h = DIST.SORTED.ROW.BY.ROW[, knn.reg + 1], kernel="Epanechnikov")[,1]
  ###########################################################################
  # estimate fuctional derivatives (with specific bandwidth choice)
  ###########################################################################
  if(derivative){
    # Step 1: compute estimated errors
    Estimated.errors = Responses - Estimated.responses
    # Set values for the wild bootstrap procedure
    gn = 0.5 * (1 + sqrt(5))
    gn.conj = 0.5 * (1 - sqrt(5))
    prob = (5 + sqrt(5)) / 10
    # Initialization
    Crit.deriv.boot = 0
    COEF.DERIV.BOOT = matrix(0, nlearn, dim.opt)
    PHIK = list()
    TEMP.INV = list()
    # Compute invariant quantities
    for(ii in 1:nlearn){
      PHI = cbind(1, t(t(INNER.LEARN) - INNER.LEARN[ii, ]))
      bwd = DIST.SORTED.ROW.BY.ROW[ii, knn.reg + 1]
      U = DIST[ii, 1:nlearn] / bwd
      Kernel = (1 - U^2) * (U < 1)
      Kernel[ii] = 0
      PHIK[[ii]] = PHI * Kernel
      TEMP = crossprod(PHIK[[ii]], PHI)
      TEMP.INV[[ii]] = solve(TEMP)
    }
    # Repeat B=100 (by default) times the wild bootstrap procedure
    if(!is.null(boot.seed)) set.seed(boot.seed)
    for(bb in 1:nboot){
      # Step 2: build bootstrapped errors
      U  = runif(nlearn)
      V = (U >= prob) * gn + (U < prob) * gn.conj
      Boostrapped.errors = Estimated.errors * V
      # Step 3: drawn the bootstrap sample
      Boostrapped.responses = Estimated.responses + Boostrapped.errors
      # Step 4: compute bootstrapped functional derivatives
      for(ii in 1:nlearn){
        Temp = crossprod(PHIK[[ii]], Boostrapped.responses)
        # Estimate simultaneously the fuctional derivatives basis expansion
        COEF.DERIV.BOOT[ii, ] = COEF.DERIV.BOOT[ii, ] + TEMP.INV[[ii]][-1, ] %*% Temp
      }
    }
    # Compute the average of the boostrapped estimations for each functional predictor in the learning sample
    COEF.DERIV.BOOT = COEF.DERIV.BOOT / nboot
    # Compute the bootstrap pilot
    PILOT.BOOT.DERIV = COEF.DERIV.BOOT %*% B
    # Determine the optimal bandwidth for estimating the functional derivatives
    rank.min = kNN.grid.length
    Knn.learn.ratio = c(0.02, 0.25, 0.5, 0.75, 0.9)
    # Build an adaptative grid of kNN (number of knearest neighbours used for determining local bandwidths)
    # If the minimum of the criterion is reached for the last bandwidth
    # then the grid "Knn.grid" is updated
    for(ratio in 1:(length(Knn.learn.ratio) - 1)){
      knn.min = max(round(nlearn * Knn.learn.ratio[ratio]), dim.max + 4)
      knn.max = round(nlearn * Knn.learn.ratio[ratio + 1])
      knn.range = knn.max - knn.min
      if(knn.range <= kNN.grid.length){
        Knn.grid = knn.min:knn.max
      }else{
        step = ceiling(knn.range / kNN.grid.length)
        Knn.grid = seq(from = knn.min, to = knn.max, by = step)
      }
      kNN.grid.length = length(Knn.grid)
      rank.min = kNN.grid.length
      #########################################################################################
      # estimate kNN
      #########################################################################################
      Crit.deriv.boot = rep(NA,kNN.grid.length)
      count = 0
      for(knn in Knn.grid){
        count = count + 1
        COEF.DERIV = llsm_leave(INNER.LEARN,INNER.LEARN,DIST,Responses,h=DIST.SORTED.ROW.BY.ROW[, knn + 1],kernel="Epa")[,-1]
        ESTIMATED.DERIV = COEF.DERIV %*% B
        # Compute the criterion for estimating the fuctional derivative
        Crit.deriv.boot[count] = mean((PILOT.BOOT.DERIV - ESTIMATED.DERIV)^2)
      }
      if(rank.min != order(Crit.deriv.boot)[1]) break
    }
    # Determine the criterion value
    crit.deriv.boot = min(Crit.deriv.boot)
    # Determine the optimal number of k-nearest neighbours for the functional derivative
    knn.deriv = (Knn.grid)[which.min(Crit.deriv.boot)]
  } else { # if the badnwidth for the derivative is just that from regression
    knn.deriv = knn.reg
  }
  # Save optimal bandwidths in terms of k-nearest neighbours into outputs
  knn.opt = list(reg = knn.reg, deriv = knn.deriv)
  COEF.DERIV = llsm(INNER.LEARN,INNER.LEARN,DIST,Responses,h=DIST.SORTED.ROW.BY.ROW[, knn.deriv + 1],kernel="Epa")[,-1]
  ESTIMATED.DERIV = COEF.DERIV %*% B
  # Compute predicted responses + predicted fuctional derivative if "outsample" is true
  # (i.e. one has additional observations for the functional predictor)
  if(outsample){
    DIST = as.matrix(parDist(rbind(LEARN, PRED), method = "euclidean")) / sqrt(gridsize - 1)
    DIST.SORTED.PRED.BY.LEARN = t(apply(DIST[-(1:nlearn), 1:nlearn], 1, sort))
    # Compute inner products between functional predictors and basis functions
    INNER.PRED = tcrossprod(PRED, B) / (gridsize - 1)
    nout = nrow(PRED)
    Predicted.responses = llsm(INNER.LEARN,INNER.PRED,DIST[-(1:nlearn), 1:nlearn],Responses,h=DIST.SORTED.PRED.BY.LEARN[,knn.reg + 1],kernel="Epa")[,1]
    COEF.PRED.DERIV = llsm(INNER.LEARN,INNER.PRED,DIST[-(1:nlearn), 1:nlearn],Responses,h=DIST.SORTED.PRED.BY.LEARN[,knn.deriv + 1],kernel="Epa")[,-1]
    PREDICTED.DERIV = COEF.PRED.DERIV %*% B
    return(list(Estimated.responses = Estimated.responses, ESTIMATED.DERIV = ESTIMATED.DERIV, Predicted.responses = Predicted.responses, PREDICTED.DERIV = PREDICTED.DERIV, mse = mse, knn.opt = knn.opt, dim.opt = dim.opt))
  }else{
    return(list(Estimated.responses = Estimated.responses, ESTIMATED.DERIV = ESTIMATED.DERIV, mse = mse, knn.opt = knn.opt, dim.opt = dim.opt))
  }
}

#' Oracle bandwidth value for functional derivative estimation
#'
#' Given the true (Riesz representatives of) functional derivatives in a scalar-on-function
#' regression problem, this function evaluates the oracle bandwidth choice for the estimation
#' of the functional derivatives in a given functional basis.
#'
#' @param Responses vector of scalar responses
#' @param LEARN     matrix of regressors, functional values evaluated at common domain,
#' one function per row
#' @param ORACLE.DERIV matrix of the true functional derivatives, each row corresponding
#' to a row of \code{LEARN}.
#' @param BASIS     basis functions into which the random functions are decomposed. One
#' function per row. The true dimension of this space is assumed to be the number of rows
#' of this matrix.
#' @param kNN.grid.length  grid length for the bandwidth search
#'
#' @return A single bandwidth in terms of the number of nearest neighbors that
#' corresponds to \code{knn.opt$deriv} from \code{\link{fllr}}. Works for \code{method = cv} only.

oracle.bw = function(Responses, LEARN, ORACLE.DERIV, BASIS, kNN.grid.length = 30)
{
  gridsize = ncol(LEARN)
  DIST = as.matrix(parDist(LEARN, method = "euclidean")) / sqrt(gridsize - 1)
  DIST.SORTED.ROW.BY.ROW = t(apply(DIST, 1, sort))
  nlearn = nrow(LEARN)
  B = BASIS
  dim = nrow(BASIS)
  INNER.LEARN = tcrossprod(LEARN, B) / (gridsize - 1)
  PILOT.BOOT.DERIV = ORACLE.DERIV
  # Determine the optimal bandwidth for estimating the functional derivatives
  rank.min = kNN.grid.length
  Knn.learn.ratio = c(0.02, 0.25, 0.5, 0.75, 0.9)
  # Build an adaptative grid of kNN (number of knearest neighbours used for determining local bandwidths)
  # If the minimum of the criterion ("MSE.REG") is reached for the bandwidth corresponding to
  # "Knn.grid[kNN.grid.length]", then the grid "Knn.grid" is updated
  for(ratio in 1:(length(Knn.learn.ratio) - 1)){
    knn.min = max(round(nlearn * Knn.learn.ratio[ratio]), dim + 4)
    knn.max = round(nlearn * Knn.learn.ratio[ratio + 1])
    knn.range = knn.max - knn.min
    if(knn.range <= kNN.grid.length){
      Knn.grid = knn.min:knn.max
    }else{
      step = ceiling(knn.range / kNN.grid.length)
      Knn.grid = seq(from = knn.min, to = knn.max, by = step)
    }
    kNN.grid.length = length(Knn.grid)
    rank.min = kNN.grid.length
    #########################################################################################
    # estimate kNN
    #########################################################################################
    Crit.deriv.boot = rep(NA,kNN.grid.length)
    count = 0
    for(knn in Knn.grid){
      count = count + 1
      COEF.DERIV = llsm_leave(INNER.LEARN,INNER.LEARN,DIST,Responses,h=DIST.SORTED.ROW.BY.ROW[, knn + 1],kernel="Epa")[,-1]
      ESTIMATED.DERIV = COEF.DERIV %*% B
      # Compute the criterion for estimating the fuctional derivative
      Crit.deriv.boot[count] = mean((PILOT.BOOT.DERIV - ESTIMATED.DERIV)^2)
    }
    if(rank.min != order(Crit.deriv.boot)[1]) break
  }
  # Determine the criterion value
  crit.deriv.boot = min(Crit.deriv.boot)
  # Determine the optimal number of k-nearest neighbours for the functional derivative
  knn.deriv = (Knn.grid)[which.min(Crit.deriv.boot)]
  # Save optimal bandwidths in terms of k-nearest neighbours into outputs
  knn.opt = knn.deriv
  return(knn.opt)
}

#' Functional additive model estimation
#'
#' Estimates the scalar-on-function model using the additive modeling approach from
#' Mueller and Yao (2008) for the regression operator, and Mueller and Yao (2010) for the
#' functional derivatives.
#'
#' @param Responses vector of scalar responses
#' @param LEARN     matrix of regressors, functional values evaluated at common domain,
#' one function per row
#' @param PRED      matrix of functions at which new values are predicted, one function
#' per row
#' @param percent   percentage of explained sample
#' variance that is taken into account when building the basis expansion in terms of
#' eigenfunctions of the empirical covariance operator.
#' @param BASIS     if basis functions are not estimated using the empirical covariance
#' operator, matrix of basis functions. One function per row.
#'
#'
#' @return A list with the following components:
#' \itemize{
#' \item \code{Predicted.responses} A vector of predicted responses, each element
#' of the vector corresponding to a row of \code{PRED}.
#' \item \code{PREDICTED.DERIV} A matrix of predicted (Riesz representations of)
#' functional derivatives, each row corresponding to a row of \code{PRED}.
#' \item \code{dim} Dimension of the eigenbasis used for both the regression operator and
#' the functional derivative. Chosen as a given percentage of total sample variance explained by
#' the first eigenfunctions of the empirical covariance operator.
#' }
#'
#' @examples
#' gridsize = 101                           # grid size
#' Grid = seq(0, 1, length = gridsize)      # grid of measurements
#' nlearn = 150                             # learning sample size
#' ntest = 150                              # testing sample size
#' sample.size = nlearn + ntest             # whole sample size
#' Jmodel = 4                               # number of basis elements used for building functional predictors
#' BASIS = phif(Jmodel, Grid)               # first Jmodel Fourier basis elements
#' UNIF = matrix(runif(sample.size * Jmodel, min = -1, max = 1), nrow = sample.size, ncol = Jmodel)
#' PREDICTORS = UNIF %*% BASIS[1:Jmodel, ]
#'
#' ##########################################
#' # Simulate the regression and functional derivative
#' ##########################################
#' TRANSFORMED.REG = exp(- UNIF^2)
#' TRANSFORMED.DERIV = - 2 * UNIF * TRANSFORMED.REG
#' Regression = apply(TRANSFORMED.REG, 1, sum)
#' DERIV = TRANSFORMED.DERIV %*% BASIS[1:Jmodel,]
#'
#' ###########################################
#' # Simulate scalar responses ("Responses")
#' ###########################################
#' error = rnorm(sample.size, sd = 1)
#' Responses.fullsample = Regression + error
#'
#' ###########################################
#' # Build learning sample
#' ###########################################
#' LEARN = PREDICTORS[1:nlearn, ]
#' PRED = PREDICTORS[-(1:nlearn), ]
#' Responses = Responses.fullsample[1:nlearn]
#'
#' res = MY(Responses, LEARN, PRED)
#'
#' plot(res$Predicted.responses~Regression[-(1:nlearn)])
#'

MY = function(Responses, LEARN, PRED, percent = .9, BASIS = NULL)
{
  outsample = T
  if(identical(LEARN,PRED)) outsample = F
  ## if LEARN is the same matrix as PRED, outsample = F
  # Estimate the second order moment operator
  gridsize = ncol(LEARN)
  if(is.null(BASIS)){
    if(outsample){
      sample.size = nrow(LEARN) + nrow(PRED)
      COV = crossprod(rbind(LEARN, PRED)) / (sample.size * (gridsize - 1))
    }else{
      sample.size = nrow(LEARN)
      COV = crossprod(LEARN) / (sample.size * (gridsize - 1))
    }
    # Compute estimated first "dim.max" eigenfunctions
    res.eig = eigen(COV, sym = T)
    # According to the guidelines from Mueller and Yao (2010, Section 3)
    # derive the approximating subspace expressing at least "percent"
    # of the total variance
    cum.part.of.variance = cumsum(res.eig$values) / sum(res.eig$values)
    dim = sum(cum.part.of.variance < percent) + 1
    BASIS = t(res.eig$vectors[, 1:dim]) * sqrt(gridsize - 1)
  } else { dim = nrow(BASIS) }
  nlearn = nrow(LEARN)
  #
  B = BASIS
  INNER.LEARN = tcrossprod(LEARN, B) / (gridsize - 1)
  INNER.PRED = tcrossprod(PRED, B) / (gridsize - 1)
  nout = nrow(PRED)
  #
  MY.raw = MuellerYao(INNER.LEARN,INNER.PRED,Responses)
  COEF.PRED.DERIV = MY.raw$coefficients
  PREDICTED.DERIV = COEF.PRED.DERIV %*% B
  Predicted.responses = mean(Responses) + rowSums(MY.raw$reg.coefficients)
  return(list(Predicted.responses = Predicted.responses, PREDICTED.DERIV = PREDICTED.DERIV, dim = dim))
}

#' Local constant functional estimation
#'
#' Estimates the scalar-on-function model using the local constant (Nadaraya-Watson's estimator)
#' for the regression operator and functional data. Does not directly provide an
#' estimator of functional derivatives. Bandwidth is chosen via leave-one-out cross-validation.
#'
#' @param Responses vector of scalar responses
#' @param DIST      a square symmetric matrix of all distances of regressor functions from
#' each other, see \code{\link{L2metric}}.
#' @param DIST.PRED an \code{m}-times-\code{n} matrix of distances of all functions at which we intend to predict (\code{m} functions)
#' from the regressor functions (\code{n} functions).
#' @param kNN.grid.length  grid length for the bandwidth search
#'
#'
#' @return A list with the following components:
#' \itemize{
#' \item \code{Predicted.responses} A vector of predicted responses, each element
#' of the vector corresponding to a function that corresponds to a row in \code{DIST}.
#' \item \code{mse} Minimum mean squared error obtained in the search for the optimal bandwidth
#' for the regression operator.
#' \item \code{knn.opt} The optimal bandwidths for the regression operator obtained by
#' leave-one-out cross-validation.
#' }
#'
#' @examples
#' gridsize = 101                           # grid size
#' Grid = seq(0, 1, length = gridsize)      # grid of measurements
#' nlearn = 150                             # learning sample size
#' ntest = 100                              # testing sample size
#' sample.size = nlearn + ntest             # whole sample size
#' Jmodel = 4                               # number of basis elements used for building functional predictors
#' BASIS = phif(Jmodel, Grid)               # first Jmodel Fourier basis elements
#' UNIF = matrix(runif(sample.size * Jmodel, min = -1, max = 1), nrow = sample.size, ncol = Jmodel)
#' PREDICTORS = UNIF %*% BASIS[1:Jmodel, ]
#'
#' ##########################################
#' # Simulate the regression and functional derivative
#' ##########################################
#' TRANSFORMED.REG = exp(- UNIF^2)
#' TRANSFORMED.DERIV = - 2 * UNIF * TRANSFORMED.REG
#' Regression = apply(TRANSFORMED.REG, 1, sum)
#' DERIV = TRANSFORMED.DERIV %*% BASIS[1:Jmodel,]
#'
#' ###########################################
#' # Simulate scalar responses ("Responses")
#' ###########################################
#' error = rnorm(sample.size, sd = 1)
#' Responses.fullsample = Regression + error
#'
#' ###########################################
#' # Build learning sample
#' ###########################################
#' LEARN = PREDICTORS[1:nlearn, ]
#' PRED = PREDICTORS[-(1:nlearn), ]
#' Responses = Responses.fullsample[1:nlearn]
#'
#' DIST = L2metric(LEARN,LEARN)
#' DIST.PRED = L2metric(PRED,LEARN)
#' res = KernelSmoother(Responses, DIST, DIST.PRED)
#'
#' plot(res$Predicted.responses~Regression[-(1:nlearn)])
#'

KernelSmoother = function(Responses, DIST, DIST.PRED, kNN.grid.length = 30)
{
  nlearn = nrow(DIST)
  DIST.SORTED.ROW.BY.ROW = t(apply(DIST, 1, sort))
  DIST.PRED.SORTED.ROW.BY.ROW = t(apply(DIST.PRED, 1, sort))
  #
  rank.min = kNN.grid.length
  Knn.learn.ratio = c(0.02, 0.25, 0.5, 0.75, 0.9)
  # Build an adaptive grid of kNN (number of k nearest neighbors used for determining local bandwidths)
  # If the minimum of the criterion ("MSE") is reached for the bandwidth corresponding to
  # "Knn.grid[kNN.grid.length]", then the grid "Knn.grid" is updated
  for(ratio in 1:(length(Knn.learn.ratio) - 1)){
    knn.min = round(nlearn * Knn.learn.ratio[ratio])
    knn.max = round(nlearn * Knn.learn.ratio[ratio + 1])
    knn.range = knn.max - knn.min
    if(knn.range <= kNN.grid.length){
      Knn.grid = knn.min:knn.max
    }else{
      step = ceiling(knn.range / kNN.grid.length)
      Knn.grid = seq(from = knn.min, to = knn.max, by = step)
    }
    kNN.grid.length = length(Knn.grid)
    rank.min = kNN.grid.length
    #########################################################################################
    # estimate regression operator with bandwidth maximizing cross validation criterion
    #########################################################################################
    MSE = rep(0, kNN.grid.length)
    H = matrix(nrow=nlearn,ncol=length(Knn.grid))
    for(knni in 1:length(Knn.grid)) H[,knni] = DIST.SORTED.ROW.BY.ROW[, Knn.grid[knni] + 1]
    MSE = ksm_cv(DIST,Responses,H=H, kernel="Epanechnikov")$CV
    if(rank.min != order(MSE)[1]) break # if minimum CV is not the last one, break
  }
  # Determine corresponding criterion value
  mse = min(MSE)
  # Determine optimal number of k-nearest neighbours and dimension J
  knn = (Knn.grid)[order(MSE)[1]]
  #
  Predicted.responses = ksm(DIST.PRED, Responses, DIST.PRED.SORTED.ROW.BY.ROW[, knn + 1])
  return(list(Predicted.responses = Predicted.responses, mse = mse, knn.opt = knn))
}

#' Functional linear model
#'
#' Estimates the standard scalar-on-function linear model, where all functional data
#' are projected into a subspace given by basis functions.
#'
#' @param Responses vector of scalar responses
#' @param LEARN     matrix of regressors, functional values evaluated at common domain,
#' one function per row
#' @param PRED      matrix of functions at which new values are predicted, one function
#' per row
#' @param percent   if \code{BASIS} is not given, percentage of explained sample
#' variance that is taken into account when building the basis expansion in terms of
#' eigenfunctions of the empirical covariance operator
#' @param BASIS     if basis functions are not estimated using the empirical covariance
#' operator, matrix of basis functions. One function per row.
#'
#' @return A list with the following components:
#' \itemize{
#' \item \code{Predicted.responses} A vector of predicted responses, each element of the vector corresponding to a row
#' of \code{PRED}.
#' \item \code{PREDICTED.DERIV} A matrix of predicted (Riesz representations of) functional derivatives,
#' each row corresponding to a row of \code{PRED}.
#' \item \code{mse} Minimum mean squared error obtained in the search leave-one-out
#' cross-validation for the optimal dimension of the basis for the regression operator.
#' \item \code{dim.opt} Optimal basis dimension used for both the regression operator and
#' the functional derivative. If \code{BASIS} is provided, \code{dim.opt} is chosen as
#' the numer of rows of \code{BASIS}.
#' }
#'
#'
#' @examples
#' gridsize = 101                           # grid size
#' Grid = seq(0, 1, length = gridsize)      # grid of measurements
#' nlearn = 150                             # learning sample size
#' ntest = 100                              # testing sample size
#' sample.size = nlearn + ntest             # whole sample size
#' Jmodel = 4                               # number of basis elements used for building functional predictors
#' BASIS = phif(Jmodel, Grid)               # first Jmodel Fourier basis elements
#' UNIF = matrix(runif(sample.size * Jmodel, min = -1, max = 1), nrow = sample.size, ncol = Jmodel)
#' PREDICTORS = UNIF %*% BASIS[1:Jmodel, ]
#'
#' ##########################################
#' # Simulate the regression and functional derivative
#' ##########################################
#' TRANSFORMED.REG = exp(- UNIF^2)
#' TRANSFORMED.DERIV = - 2 * UNIF * TRANSFORMED.REG
#' Regression = apply(TRANSFORMED.REG, 1, sum)
#' DERIV = TRANSFORMED.DERIV %*% BASIS[1:Jmodel,]
#'
#' ###########################################
#' # Simulate scalar responses ("Responses")
#' ###########################################
#' error = rnorm(sample.size, sd = 1)
#' Responses.fullsample = Regression + error
#'
#' ###########################################
#' # Build learning sample
#' ###########################################
#' LEARN = PREDICTORS[1:nlearn, ]
#' PRED = PREDICTORS[-(1:nlearn), ]
#' Responses = Responses.fullsample[1:nlearn]
#'
#' res = LinearModel(Responses, LEARN, PRED)
#'
#' plot(res$Predicted.responses~Regression[-(1:nlearn)])
#'

LinearModel = function(Responses, LEARN, PRED, percent = 0.95, BASIS = NULL)
{
  outsample = T
  if(identical(LEARN,PRED)) outsample = F
  ## if LEARN is the same matrix as PRED, outsample = F and PRED = LEARN
  ##
  # Estimate the second order moment operator
  nlearn = nrow(LEARN)
  gridsize = ncol(LEARN)
  if(is.null(BASIS)){
    if(outsample){
      sample.size = nrow(LEARN) + nrow(PRED)
      COV = crossprod(rbind(LEARN, PRED)) / (sample.size * (gridsize - 1))
    }else{
      sample.size = nrow(LEARN)
      COV = crossprod(LEARN) / (sample.size * (gridsize - 1))
    }
    # Compute estimated first "dim.max" eigenfunctions
    res.eig = eigen(COV, sym = T)
    # Drop first eigenvalue and derive the approximating subspace expressing at least "percent"
    # of the remaining total variance
    cum.part.of.variance = cumsum(res.eig$values[-1]) / sum(res.eig$values[-1])
    dim.max = sum(cum.part.of.variance < percent) + 2
    BASIS = t(res.eig$vectors[, 1:dim.max]) * sqrt(gridsize - 1)
  } else { dim.max = nrow(BASIS) }

  INNER.LEARN = tcrossprod(LEARN, BASIS) / (gridsize - 1)
  H = matrix(Inf, nrow=nrow(INNER.LEARN),ncol=1)
  MSE = llsm_cv(matrix(INNER.LEARN,ncol=dim.max),matrix(0,nrow=nlearn,ncol=nlearn),Responses,H=H,kernel="Epanechnikov")$CV
  dim.opt = order(MSE)[1]-1
  mse = min(MSE)
  nout = nrow(PRED)

  if(dim.opt==0){
    Predicted.responses = rep(mean(Responses),nout) # llsm(NULL,NULL,matrix(0,nrow=nout,ncol=nlearn),Responses,h=Inf,kernel="Epa")
    PREDICTED.DERIV = matrix(0,nrow=nout,ncol=gridsize)
  } else {
    B = matrix(BASIS[1:dim.opt,],nrow=dim.opt)
    INNER.LEARN = matrix(INNER.LEARN[,1:dim.opt],ncol=dim.opt)
    INNER.PRED = tcrossprod(PRED, B) / (gridsize - 1)
    # res = llsm(INNER.LEARN,INNER.PRED,matrix(0,nrow=nout,ncol=nlearn),Responses,h=Inf,kernel="Epa")
    # summary(cbind(1,INNER.PRED)%*%linmod$coef-res[,1])
    linmod = lm(Responses~INNER.LEARN)
    Predicted.responses = cbind(1,INNER.PRED)%*%linmod$coef
    PREDICTED.DERIV = matrix(rep(linmod$coef[-1],nout),nrow=nout,byrow=TRUE)%*%B
  }
  return(list(Predicted.responses = Predicted.responses, PREDICTED.DERIV = PREDICTED.DERIV, mse = mse, dim.opt = dim.opt))
}

###
# fllr
###

matsolve <- function(a, b)
{
  stopifnot(is.numeric(a))
  stopifnot(is.numeric(b))
  stopifnot(is.finite(a))
  stopifnot(is.finite(b))
  stopifnot(is.matrix(a))
  # stopifnot(a == t(a))
  b <- as.matrix(b)
  stopifnot(nrow(a) == nrow(b))
  storage.mode(a) <- "double"
  storage.mode(b) <- "double"
  .C("matsolve", a = a, b = b, nrowb = nrow(b), ncolb = ncol(b),
     PACKAGE = "fllr")$b
}

#' Cross-validation for the local constant smoother
#'
#' For the local constant smoother (Nadaraya-Watson's estimator)
#' in the scalar-on-function linear model, given a sequence of bandwidths,
#' returns a sequence of (leave-one-out) cross-validated mean squared errors
#' for bandwidth selection.
#'
#' @param D         symmetric square matrix of distances of the functional data from each
#' other, one row per function
#' @param Y         vector of scalar responses
#' @param H         bandwidths to be considered. Could be either a vector of bandwidths that
#' will be applied to each function, or a matrix with individual bandwidths applied to
#' learning function, one row per function. Alternatively, if \code{kNN} is specified,
#' the bandwidth matrix is built automatically using the local nearest neighbors bandwidths.
#' @param kNN       sequence of nearest neighbors (as a fraction of total number of neighbors, i.e.
#' a number between 0 and 1) to be considered for local bandwidth
#' selection. If \code{kNN} is provided, matrix \code{H} is build automatically by
#' evaluating sample quantiles of the distances in rows of the matrix of distances \code{D}.
#' @param nCV       if provided, only the first \code{nCV} leave-one-out cross-validated
#' trials is considered in the resulting mean squared error. By default, all functions are
#' included in cross-validation.
#' @param kernel    kernel function. Possible choices are \code{"uniform"}, \code{"triangular"},
#' \code{"Epanechnikov"}, \code{"biweight"}, \code{"triweight"}, and \code{"Gaussian"}.
#' @param quantile.type if \code{kNN} is provided, parameter that enters function \code{\link{quantile}}
#' that specifies the type of the sample quantile taken
#'
#' @return A list with the following components:
#' \itemize{
#' \item \code{CV} A matrix that corresponds to \code{H} that contains all the resulting
#' mean squared errors of the cross-validation procedure.
#' \item \code{kernel} Kernel used.
#' }
#'
#'
#' @examples
#' gridsize = 101                           # grid size
#' Grid = seq(0, 1, length = gridsize)      # grid of measurements
#' nlearn = 150                             # learning sample size
#' ntest = 100                              # testing sample size
#' sample.size = nlearn + ntest             # whole sample size
#' Jmodel = 4                               # number of basis elements used for building functional predictors
#' BASIS = phif(Jmodel, Grid)               # first Jmodel Fourier basis elements
#' UNIF = matrix(runif(sample.size * Jmodel, min = -1, max = 1), nrow = sample.size, ncol = Jmodel)
#' PREDICTORS = UNIF %*% BASIS[1:Jmodel, ]
#'
#' ##########################################
#' # Simulate the regression and functional derivative
#' ##########################################
#' TRANSFORMED.REG = exp(- UNIF^2)
#' TRANSFORMED.DERIV = - 2 * UNIF * TRANSFORMED.REG
#' Regression = apply(TRANSFORMED.REG, 1, sum)
#' DERIV = TRANSFORMED.DERIV %*% BASIS[1:Jmodel,]
#'
#' ###########################################
#' # Simulate scalar responses ("Responses")
#' ###########################################
#' error = rnorm(sample.size, sd = 1)
#' Responses.fullsample = Regression + error
#'
#' ###########################################
#' # Build learning sample
#' ###########################################
#' LEARN = PREDICTORS[1:nlearn, ]
#' PRED = PREDICTORS[-(1:nlearn), ]
#' Responses = Responses.fullsample[1:nlearn]
#'
#' ksm_cv(L2metric(LEARN, LEARN), Responses, kNN = seq(.1,.9,length=11), kernel = "Gauss")
#'

ksm_cv <- function(D,Y,H=NULL,kNN=NULL,nCV=NULL, kernel=c("uniform","triangular","Epanechnikov","biweight","triweight","Gaussian"),quantile.type=7) {
  krn = c("uniform","triangular","Epanechnikov","biweight","triweight","Gaussian")
  kernel = match.arg(kernel)
  kernI = which(kernel==krn)
  if(is.null(H) & is.null(kNN)) stop("Neither candidate bandwidths nor nearest neighbour proportions specified.")
  if((!is.null(H)) & (!is.null(kNN))) stop("Specify either bandwidths or nearest neighbour proportions, not both.")
  # construct full matrix of candidate bandwidths, different for each function
  if(is.null(H)) Heval = length(kNN)
  if(is.null(kNN)){ if(is.null(dim(H))) Heval = length(H) else Heval = ncol(H) }
  Hf = matrix(nrow=nrow(D),ncol=Heval) # each function has now its own sequence of candidate bw
  for(i in 1:nrow(D)){
    if(is.null(H)){
      Hf[i,] = quantile(D[i,-i],kNN,type=quantile.type)
      Hf[i,kNN==1] = Inf
    }
    if(is.null(kNN)){
      if(is.null(dim(H))) Hf[i,] = H else Hf[i,] = H[i,]
    }
  }
  Hf[!is.finite(Hf)] = -1
  if(is.null(nCV)) nCV = nrow(D)
  if(nCV>nrow(D)) nCV = nrow(D)
  out <- .C("ksm_cv", D = as.double(D), Y = as.double(Y), n = as.integer(nrow(D)),
            Hf = as.double(Hf), nH = as.integer(Heval),
            CV=as.double(rep(0,Heval)), nCV = as.integer(nCV),
            kernI = as.integer(kernI))
  CV = out$CV
  Hf[Hf==-1] = Inf # back to the usual coding for Inf
  if(!is.null(H)){ # H cross-validation
    return(list(CV = CV, kernel = kernel))
  }
  if(is.null(H)){ # kNN cross-validation
    return(list(CV = CV, kernel = kernel))
  }
}

#' Local constant smoother with a fixed bandwidth
#'
#' The local constant smoother (Nadaraya-Watson's estimator)
#' in the scalar-on-function linear model with a given bandwidth.
#'
#' @param D         a (possibly non-symmetric) matrix of distances of the learning sample
#' of functional data from the predictor functions, one row per a learning sample function
#' @param Y         vector of scalar responses
#' @param h         a single bandwidth. Alternatively, if \code{kNN} is specified,
#' local bandwidths are built automatically using the nearest neighbors.
#' @param kNN       number of nearest neighbors (as a fraction of total number of neighbors, i.e.
#' a number between 0 and 1) to be considered for local bandwidth
#' selection. If \code{kNN} is provided, vector \code{h} is build automatically by
#' evaluating sample quantiles of the distances in rows of the matrix of distances \code{D}.
#' @param kernel    kernel function. Possible choices are \code{"uniform"}, \code{"triangular"},
#' \code{"Epanechnikov"}, \code{"biweight"}, \code{"triweight"}, and \code{"Gaussian"}.
#' @param quantile.type if \code{kNN} is provided, parameter that enters function \code{\link{quantile}}
#' that specifies the type of the sample quantile taken
#'
#' @return A vector of predicted responses whose length is the number of columns of \code{D}.
#'
#'
#' @examples
#' gridsize = 101                           # grid size
#' Grid = seq(0, 1, length = gridsize)      # grid of measurements
#' nlearn = 150                             # learning sample size
#' ntest = 100                              # testing sample size
#' sample.size = nlearn + ntest             # whole sample size
#' Jmodel = 4                               # number of basis elements used for building functional predictors
#' BASIS = phif(Jmodel, Grid)               # first Jmodel Fourier basis elements
#' UNIF = matrix(runif(sample.size * Jmodel, min = -1, max = 1), nrow = sample.size, ncol = Jmodel)
#' PREDICTORS = UNIF %*% BASIS[1:Jmodel, ]
#'
#' ##########################################
#' # Simulate the regression and functional derivative
#' ##########################################
#' TRANSFORMED.REG = exp(- UNIF^2)
#' TRANSFORMED.DERIV = - 2 * UNIF * TRANSFORMED.REG
#' Regression = apply(TRANSFORMED.REG, 1, sum)
#' DERIV = TRANSFORMED.DERIV %*% BASIS[1:Jmodel,]
#'
#' ###########################################
#' # Simulate scalar responses ("Responses")
#' ###########################################
#' error = rnorm(sample.size, sd = 1)
#' Responses.fullsample = Regression + error
#'
#' ###########################################
#' # Build learning sample
#' ###########################################
#' LEARN = PREDICTORS[1:nlearn, ]
#' PRED = PREDICTORS[-(1:nlearn), ]
#' Responses = Responses.fullsample[1:nlearn]
#'
#' ksm(L2metric(LEARN, PRED), Responses, kNN = .2, kernel = "Gauss")
#'

ksm <- function(D, Y, h=NULL, kNN = NULL, kernel=c("uniform","triangular","Epanechnikov","biweight","triweight","Gaussian"), quantile.type=7) {

  if(is.null(dim(D))) D = matrix(D,nrow=1)
  if(is.null(h) & is.null(kNN)) stop("Neither bandwidth nor nearest neighbour proportion specified.")
  if((!is.null(h)) & (!is.null(kNN))) stop("Specify either bandwidth or nearest neighbour proportion, not both.")
  if(is.null(h) & (!is.null(kNN))){
    h = apply(D,1,function(x) quantile(x,kNN,type=quantile.type))
    if(kNN == 1) h = rep(Inf,nrow(D))
  }
  if(length(h)==1) h = rep(h,nrow(D))
  h[!is.finite(h)] = -1
  krn = c("uniform","triangular","Epanechnikov","biweight","triweight","Gaussian")
  kernel = match.arg(kernel)
  kernI = which(kernel==krn)
  out <- .C("ksm", D = as.double(D), Y = as.double(Y), h = as.double(h),
            n = as.integer(length(Y)), m = as.integer(nrow(D)),
            kernI = as.integer(kernI), res=as.double(rep(0,nrow(D))))
  return(out$res)
}

matvecmult <- function(a, x)
{
  stopifnot(is.numeric(a))
  stopifnot(is.numeric(x))
  stopifnot(is.finite(a))
  stopifnot(is.finite(x))
  stopifnot(is.matrix(a))
  stopifnot(ncol(a) == length(x))
  .C("matvecmult", a = as.double(a), x = as.double(x),
     nrow = nrow(a), ncol = ncol(a), result = double(nrow(a)),
     PACKAGE = "fllr")$result
}

matmatmult <- function(a, b)
{
  stopifnot(is.numeric(a))
  stopifnot(is.numeric(b))
  stopifnot(is.finite(a))
  stopifnot(is.finite(b))
  stopifnot(is.matrix(a))
  stopifnot(is.matrix(b))
  stopifnot(ncol(a) == nrow(b))
  .C("matmatmult", a = as.double(a), b = as.double(b),
     nrowa = nrow(a), ncola = ncol(a), ncolb = ncol(b),
     c = matrix(as.double(0), nrow = nrow(a), ncol = ncol(b)),
     PACKAGE = "fllr")$c
}

#' Functional local linear smoother with a fixed bandwidth
#'
#' The functional local linear smoother
#' in the scalar-on-function linear model with a given bandwidth.
#'
#' @param C         a matrix of the basis coefficients of the the learning sample
#' functions (n functions), one row per function
#' @param Cnew      a matrix of the basis coefficients of the predictor functions
#' (m functions), one row per predictor
#' @param D         a matrix of distances of the predictor functions from the
#' learning sample functions (m-times-n matrix), one row per a predictor
#' @param Y         vector of scalar responses
#' @param h         either a single bandwidth, or a vector of m bandwidths to be used
#' for the predictor functions. Alternatively, if \code{kNN} is specified,
#' local bandwidths are built automatically using the nearest neighbors.
#' @param kNN       number of nearest neighbors (as a fraction of total number of neighbors, i.e.
#' a number between 0 and 1) to be considered for local bandwidth
#' selection. If \code{kNN} is provided, vector \code{h} is build automatically by
#' evaluating sample quantiles of the distances in rows of the matrix of distances \code{D}.
#' @param kernel    kernel function. Possible choices are \code{"uniform"}, \code{"triangular"},
#' \code{"Epanechnikov"}, \code{"biweight"}, \code{"triweight"}, and \code{"Gaussian"}.
#' @param quantile.type if \code{kNN} is provided, parameter that enters function \code{\link{quantile}}
#' that specifies the type of the sample quantile taken
#'
#' @return A matrix where each row corresponds to a single predictor.
#' The columns are the estimated regression coefficients in the given basis expansion.
#' The first column is the intercept - an estimate of the regression operator. Remaining
#' columns correspond to the basis expansion of the estimator of the functional derivative
#' of the regression operator.
#'
#'
#' @examples
#' gridsize = 101                           # grid size
#' Grid = seq(0, 1, length = gridsize)      # grid of measurements
#' nlearn = 150                             # learning sample size
#' ntest = 100                              # testing sample size
#' sample.size = nlearn + ntest             # whole sample size
#' Jmodel = 4                               # number of basis elements used for building functional predictors
#' BASIS = phif(Jmodel, Grid)               # first Jmodel Fourier basis elements
#' UNIF = matrix(runif(sample.size * Jmodel, min = -1, max = 1), nrow = sample.size, ncol = Jmodel)
#' PREDICTORS = UNIF %*% BASIS[1:Jmodel, ]
#'
#' ##########################################
#' # Simulate the regression and functional derivative
#' ##########################################
#' TRANSFORMED.REG = exp(- UNIF^2)
#' TRANSFORMED.DERIV = - 2 * UNIF * TRANSFORMED.REG
#' Regression = apply(TRANSFORMED.REG, 1, sum)
#' DERIV = TRANSFORMED.DERIV %*% BASIS[1:Jmodel,]
#'
#' ###########################################
#' # Simulate scalar responses ("Responses")
#' ###########################################
#' error = rnorm(sample.size, sd = 1)
#' Responses.fullsample = Regression + error
#'
#' ###########################################
#' # Build learning sample
#' ###########################################
#' LEARN = PREDICTORS[1:nlearn, ]
#' PRED = PREDICTORS[-(1:nlearn), ]
#' Responses = Responses.fullsample[1:nlearn]
#'
#' C = project(LEARN,BASIS)
#' Cnew = project(PRED,BASIS)
#' D = L2metric(PRED,LEARN)
#' res = llsm(C, Cnew, D, Responses, kNN = .05, kernel = "Gauss")
#'
#' plot(res[,1]~Regression[-(1:nlearn)])

llsm <- function(C, Cnew, D, Y, h=NULL, kNN = NULL, kernel=c("uniform","triangular","Epanechnikov","biweight","triweight","Gaussian"), quantile.type=7) {
  if(is.null(dim(D))){
    D = matrix(D,nrow=1)
  }
  krn = c("uniform","triangular","Epanechnikov","biweight","triweight","Gaussian")
  kernel = match.arg(kernel)
  kernI = which(kernel==krn)
  if(is.null(h) & is.null(kNN)) stop("Neither bandwidth nor nearest neighbour proportion specified.")
  if((!is.null(h)) & (!is.null(kNN))) stop("Specify either bandwidth or nearest neighbour proportion, not both.")
  if(is.null(h) & (!is.null(kNN))){
    h = apply(D,1,function(x) quantile(x,kNN,type=quantile.type))
    if(kNN == 1) h = rep(Inf,nrow(D)) # if all functions should be used perform usual (linear) regression
  }
  # if(h==Inf) return(llsm(C,Cnew,rep(1,length(D)),Y,h=-1,allJ = allJ, kernel = kernel)) # if h==Inf return usual regression output
  h[!is.finite(h)] = -1
  if(is.null(C)){
    iC = matrix(1,nrow=ncol(D))
    iCnew = matrix(1,nrow=nrow(D),1)
  } else {
    iC<-cbind(1,C)
    iCnew = matrix(NA,nrow(D),ncol(iC))
    iCnew[,1] = 1
    iCnew[,-1] = Cnew
  }
  out <- .C("llsm_single", C = as.double(iC), Cnew = as.double(iCnew), D = as.double(D), Y = as.double(Y),
            h = as.double(h),
            n = as.integer(nrow(iC)), m = as.integer(nrow(D)), J = as.integer(ncol(iC)),
            kernI = as.integer(kernI),
            res=as.double(rep(0,nrow(D)*ncol(iC))))
  return(matrix(out$res,nrow=nrow(D)))
}

llsm_leave <- function(C, Cnew, D, Y, h=NULL, kNN = NULL, kernel=c("uniform","triangular","Epanechnikov","biweight","triweight","Gaussian"), quantile.type=7) {
  ## input:
  # C:    basis coefficients of the X functions (matrix n*J)
  # Cnew: basis coefficients of the new regressor x0 (matrix m*J)
  # D:    matrix of distances of x0 from the X functions (matrix m*n)
  # Y:    response vector (vector n)
  # h:    bandwidth (vector m or vector 1, in latter case replicated)
  # kNN:  proportion of k-nearest neighbors to be used in bandwidth definition (in the interval (0,1))

  if(is.null(dim(D))){
    D = matrix(D,nrow=1)
  }
  krn = c("uniform","triangular","Epanechnikov","biweight","triweight","Gaussian")
  kernel = match.arg(kernel)
  kernI = which(kernel==krn)
  if(is.null(h) & is.null(kNN)) stop("Neither bandwidth nor nearest neighbour proportion specified.")
  if((!is.null(h)) & (!is.null(kNN))) stop("Specify either bandwidth or nearest neighbour proportion, not both.")
  if(is.null(h) & (!is.null(kNN))){
    h = apply(D,1,function(x) quantile(x,kNN,type=quantile.type))
    if(kNN == 1) h = rep(Inf,nrow(D)) # if all functions should be used perform usual (linear) regression
  }
  # if(h==Inf) return(llsm(C,Cnew,rep(1,length(D)),Y,h=-1,allJ = allJ, kernel = kernel)) # if h==Inf return usual regression output
  h[!is.finite(h)] = -1
  if(is.null(C)){
    iC = matrix(1,nrow=ncol(D))
    iCnew = matrix(1,nrow=nrow(D),1)
  } else {
    iC<-cbind(1,C)
    iCnew = matrix(NA,nrow(D),ncol(iC))
    iCnew[,1] = 1
    iCnew[,-1] = Cnew
  }
  out <- .C("llsm_single_leave", C = as.double(iC), Cnew = as.double(iCnew), D = as.double(D), Y = as.double(Y),
            h = as.double(h),
            n = as.integer(nrow(iC)), m = as.integer(nrow(D)), J = as.integer(ncol(iC)),
            kernI = as.integer(kernI),
            res=as.double(rep(0,nrow(D)*ncol(iC))))
  return(matrix(out$res,nrow=nrow(D)))
}

#' Cross-validation for the functional local linear smoother
#'
#' For the functional local linear smoother
#' in the scalar-on-function linear model, given a sequence of bandwidths,
#' returns a sequence of (leave-one-out) cross-validated mean squared errors
#' for bandwidth selection.
#'
#' @param C         a matrix of the basis coefficients of the the learning sample
#' functions (n functions), one row per function
#' @param D         a symmetric square matrix of distances of the learning sample
#' functions from themselves (n-times-n matrix), one row per a function
#' @param Y         vector of scalar responses
#' @param H         bandwidths to be considered. Could be either a vector of bandwidths that
#' will be applied to each function, or a matrix with individual bandwidths applied to
#' learning functions, one row per function. Alternatively, if \code{kNN} is specified,
#' the bandwidth matrix is built automatically using the local nearest neighbors bandwidths.
#' @param kNN       sequence of nearest neighbors (as a fraction of total number of neighbors, i.e.
#' a number between 0 and 1) to be considered for local bandwidth
#' selection. If \code{kNN} is provided, matrix \code{H} is build automatically by
#' evaluating sample quantiles of the distances in rows of the matrix of distances \code{D}.
#' @param nCV       if provided, only the first \code{nCV} leave-one-out cross-validated
#' trials is considered in the resulting mean squared error. By default, all functions are
#' included in cross-validation.
#' @param kernel    kernel function. Possible choices are \code{"uniform"}, \code{"triangular"},
#' \code{"Epanechnikov"}, \code{"biweight"}, \code{"triweight"}, and \code{"Gaussian"}.
#' @param quantile.type if \code{kNN} is provided, parameter that enters function \code{\link{quantile}}
#' that specifies the type of the sample quantile taken
#'
#' @return A list with the following components:
#' \itemize{
#' \item \code{CV} A matrix that corresponds to \code{H} that contains all the resulting
#' mean squared errors of the cross-validation procedure.
#' \item \code{CVB} A matrix that corresponds to \code{H} that contains all the resulting
#' variance estimates (mean squared errors - bias squared) of the cross-validation procedure.
#' \item \code{kernel} Kernel used.
#' }
#'
#'
#' @examples
#' gridsize = 101                           # grid size
#' Grid = seq(0, 1, length = gridsize)      # grid of measurements
#' nlearn = 150                             # learning sample size
#' ntest = 100                              # testing sample size
#' sample.size = nlearn + ntest             # whole sample size
#' Jmodel = 4                               # number of basis elements used for building functional predictors
#' BASIS = phif(Jmodel, Grid)               # first Jmodel Fourier basis elements
#' UNIF = matrix(runif(sample.size * Jmodel, min = -1, max = 1), nrow = sample.size, ncol = Jmodel)
#' PREDICTORS = UNIF %*% BASIS[1:Jmodel, ]
#'
#' ##########################################
#' # Simulate the regression and functional derivative
#' ##########################################
#' TRANSFORMED.REG = exp(- UNIF^2)
#' TRANSFORMED.DERIV = - 2 * UNIF * TRANSFORMED.REG
#' Regression = apply(TRANSFORMED.REG, 1, sum)
#' DERIV = TRANSFORMED.DERIV %*% BASIS[1:Jmodel,]
#'
#' ###########################################
#' # Simulate scalar responses ("Responses")
#' ###########################################
#' error = rnorm(sample.size, sd = 1)
#' Responses.fullsample = Regression + error
#'
#' ###########################################
#' # Build learning sample
#' ###########################################
#' LEARN = PREDICTORS[1:nlearn, ]
#' PRED = PREDICTORS[-(1:nlearn), ]
#' Responses = Responses.fullsample[1:nlearn]
#'
#' C = project(LEARN,BASIS)
#' D = L2metric(LEARN,LEARN)
#' llsm_cv(C, D, Responses, kNN = seq(.1,.9,length=11), kernel = "Gauss")
#'

llsm_cv <- function(C,D,Y,H=NULL,kNN=NULL,nCV=NULL, kernel=c("uniform","triangular","Epanechnikov","biweight","triweight","Gaussian"), quantile.type=7) {

  krn = c("uniform","triangular","Epanechnikov","biweight","triweight","Gaussian")
  kernel = match.arg(kernel)
  kernI = which(kernel==krn)
  if(is.null(H) & is.null(kNN)) stop("Neither candidate bandwidths nor nearest neighbour proportions specified.")
  if((!is.null(H)) & (!is.null(kNN))) stop("Specify either bandwidths or nearest neighbour proportions, not both.")
  # construct full matrix of candidate bandwidths, different for each function
  if(is.null(H)) Heval = length(kNN)
  if(is.null(kNN)){ if(is.null(dim(H))) Heval = length(H) else Heval = ncol(H) }
  Hf = matrix(nrow=nrow(D),ncol=Heval) # each function has now its own sequence of candidate bw
  for(i in 1:nrow(D)){
    if(is.null(H)){
      Hf[i,] = quantile(D[i,-i],kNN,type=quantile.type)
      Hf[i,kNN==1] = Inf
    }
    if(is.null(kNN)){
      if(is.null(dim(H))) Hf[i,] = H else Hf[i,] = H[i,]
    }
  }
  Hind = matrix(0,nrow=nrow(D), ncol=Heval);
  # Hind = (Hf>max(apply(D,1,function(x) quantile(x,10/nrow(D))))) # indicator for which H to perform also derivative cross-validation
  Hf[!is.finite(Hf)] = -1  # -1 is the code for usual linear regression
  if(is.null(C)){
    iC = matrix(1,nrow=nrow(D))
    iCnew = 1
  } else {
    iC<-cbind(1,C)
  }
  if(is.null(nCV)) nCV = nrow(D)
  if(nCV>nrow(D)) nCV = nrow(D)
  out <- .C("llsm_cv",
            C = as.double(iC), D = as.double(D), Y = as.double(Y),
            n = as.integer(nrow(D)), J = as.integer(ncol(iC)),
            Hf = as.double(Hf), Hind = as.integer(Hind), nH = as.integer(Heval),
            CV = rep(0,Heval*ncol(iC)),
            CVB = rep(0,Heval*ncol(iC)),
            CVD = rep(0,Heval*ncol(iC)),
            nCV = as.integer(nCV),
            kernI = as.integer(kernI),
            res = as.double(rep(0,ncol(iC)*ncol(iC)))
            # Yt = as.double(rep(0,ncol(iC)*ncol(iC))),
            # Ci = as.double(rep(0,(nrow(D)-1)*ncol(iC))),
            # Yi = as.double(rep(0,nrow(D)-1)),
            # Di = as.double(rep(0,nrow(D)-1)),
            # Cinew = as.double(rep(0,ncol(iC)))
  )
  CVM = matrix(out$CV,nrow=Heval)
  CVM[is.na(CVM)] = Inf
  CVB = matrix(out$CVB,nrow=Heval)
  CVB[is.na(CVB)] = Inf
  CVDM = matrix(out$CVD,nrow=Heval)
  CVDM[is.na(CVDM)] = Inf
  # if(inf){  # if Inf is in H, perform usual linear regression too (limit case as h->Inf)
  #   # that is the same as to ignore the information about the distances (D)
  #   # for derivative-based cross-validation, take H very large (matters only in this cross-validation procedure)
  #   R = llsm_cv(C,D,Y,H=Inf,nCV = nCV)
  #   CVM = rbind(CVM,R$CV)
  #   CVDM = rbind(CVDM,R$CVD)
  #   H = c(H,Inf)
  # }
  Hf[Hf==-1] = Inf # back to the usual coding for Inf
  if(!is.null(H)){ # H cross-validation
    # rownames(CVM) = rownames(CVB) = rownames(CVDM) = paste("H=",round(H,2),sep="")
    colnames(CVM) = colnames(CVB) = colnames(CVDM) = paste("J=",0:ncol(C),sep="")
    # h = H[apply(CVM,2,which.min)]
    # hD = H[apply(CVDM,2,which.min)]
    return(list(CV = CVM, CVB = CVB, kernel = kernel))
  }
  if(is.null(H)){ # kNN cross-validation
    rownames(CVM) = rownames(CVB) = rownames(CVDM) = paste("kNN=",round(kNN,2),sep="")
    colnames(CVM) = colnames(CVB) = colnames(CVDM) = paste("J=",0:ncol(C),sep="")
    # h = H[apply(CVM,2,which.min)]
    # hD = H[apply(CVDM,2,which.min)]
    return(list(CV=CVM, CVB = CVB, kernel = kernel))
  }
}

llsm_cv_single <- function(C,D,Y,H=NULL,kNN=NULL,nCV=NULL, kernel=c("uniform","triangular","Epanechnikov","biweight","triweight","Gaussian"), quantile.type=7) {
  ## input:
  # C:      basis coefficients of the X functions (matrix n*J)
  # D:      matrix of distances of X from X functions (matrix n*n)
  # Y:      response vector (vector n)
  # H:      sequence of bandwidths to cross-validate for
  # in CV for derivative, only such H are taken so that at least 10 functions are in
  # the h-neighborhood of any function x / otherwise we get very unstable, unreliable
  # results
  # kNN:    proportion of k-nearest neighbors to be used in bandwidth definition (in the interval (0,1))
  # quantile.type: type option in quantile function (see ?quantile)

  krn = c("uniform","triangular","Epanechnikov","biweight","triweight","Gaussian")
  kernel = match.arg(kernel)
  kernI = which(kernel==krn)
  if(is.null(H) & is.null(kNN)) stop("Neither candidate bandwidths nor nearest neighbour proportions specified.")
  if((!is.null(H)) & (!is.null(kNN))) stop("Specify either bandwidths or nearest neighbour proportions, not both.")
  # construct full matrix of candidate bandwidths, different for each function
  if(is.null(H)) Heval = length(kNN)
  if(is.null(kNN)){ if(is.null(dim(H))) Heval = length(H) else Heval = ncol(H) }
  Hf = matrix(nrow=nrow(D),ncol=Heval) # each function has now its own sequence of candidate bw
  for(i in 1:nrow(D)){
    if(is.null(H)){
      Hf[i,] = quantile(D[i,-i],kNN,type=quantile.type)
      Hf[i,kNN==1] = Inf
    }
    if(is.null(kNN)){
      if(is.null(dim(H))) Hf[i,] = H else Hf[i,] = H[i,]
    }
  }
  Hind = matrix(0,nrow=nrow(D), ncol=Heval);
  # Hind = (Hf>max(apply(D,1,function(x) quantile(x,10/nrow(D))))) # indicator for which H to perform also derivative cross-validation
  Hf[!is.finite(Hf)] = -1  # -1 is the code for usual linear regression
  if(is.null(C)){
    iC = matrix(1,nrow=nrow(D))
    iCnew = 1
  } else {
    iC<-cbind(1,C)
  }
  if(is.null(nCV)) nCV = nrow(D)
  if(nCV>nrow(D)) nCV = nrow(D)
  out <- .C("llsm_cv_single",
            C = as.double(iC), D = as.double(D), Y = as.double(Y),
            n = as.integer(nrow(D)), J = as.integer(ncol(iC)),
            Hf = as.double(Hf), Hind = as.integer(Hind), nH = as.integer(Heval),
            CV = rep(0,Heval*ncol(iC)),
            CVB = rep(0,Heval*ncol(iC)),
            CVD = rep(0,Heval*ncol(iC)),
            nCV = as.integer(nCV),
            kernI = as.integer(kernI),
            res = as.double(rep(0,ncol(iC)*ncol(iC)))
            # Yt = as.double(rep(0,ncol(iC)*ncol(iC))),
            # Ci = as.double(rep(0,(nrow(D)-1)*ncol(iC))),
            # Yi = as.double(rep(0,nrow(D)-1)),
            # Di = as.double(rep(0,nrow(D)-1)),
            # Cinew = as.double(rep(0,ncol(iC)))
  )
  CVM = matrix(out$CV,nrow=Heval)
  CVM[is.na(CVM)] = Inf
  CVB = matrix(out$CVB,nrow=Heval)
  CVB[is.na(CVB)] = Inf
  CVDM = matrix(out$CVD,nrow=Heval)
  CVDM[is.na(CVDM)] = Inf
  # if(inf){  # if Inf is in H, perform usual linear regression too (limit case as h->Inf)
  #   # that is the same as to ignore the information about the distances (D)
  #   # for derivative-based cross-validation, take H very large (matters only in this cross-validation procedure)
  #   R = llsm_cv(C,D,Y,H=Inf,nCV = nCV)
  #   CVM = rbind(CVM,R$CV)
  #   CVDM = rbind(CVDM,R$CVD)
  #   H = c(H,Inf)
  # }
  Hf[Hf==-1] = Inf # back to the usual coding for Inf
  if(!is.null(H)){ # H cross-validation
    # rownames(CVM) = rownames(CVB) = rownames(CVDM) = paste("H=",round(H,2),sep="")
    colnames(CVM) = colnames(CVB) = colnames(CVDM) = paste("J=",0:ncol(C),sep="")
    # h = H[apply(CVM,2,which.min)]
    # hD = H[apply(CVDM,2,which.min)]
    return(list(CV = CVM, CVB = CVB, kernel = kernel))
  }
  if(is.null(H)){ # kNN cross-validation
    rownames(CVM) = rownames(CVB) = rownames(CVDM) = paste("kNN=",round(kNN,2),sep="")
    colnames(CVM) = colnames(CVB) = colnames(CVDM) = paste("J=",0:ncol(C),sep="")
    # h = H[apply(CVM,2,which.min)]
    # hD = H[apply(CVDM,2,which.min)]
    return(list(CV=CVM, CVB = CVB, kernel = kernel))
  }
}

#' Basis projection
#'
#' Project a set of functions onto a basis.
#'
#' @param X         a vector of a single function, or a matrix with one function per row
#' @param basis     a matrix of basis functions, one function per row
#'
#' @return A matrix of coefficients of the functions in \code{X} with respect to the
#' basis in \code{basis}.
#'
#' @examples
#' gridsize = 101                           # grid size
#' Grid = seq(0, 1, length = gridsize)      # grid of measurements
#' n = 150
#' Jmodel = 4                               # number of basis elements
#' BASIS = phif(Jmodel, Grid)               # first Jmodel Fourier basis elements
#' UNIF = matrix(runif(sample.size * Jmodel, min = -1, max = 1), nrow = sample.size, ncol = Jmodel)
#'
#' PREDICTORS = UNIF %*% BASIS[1:Jmodel, ]
#' PREDICTORS2 = expand(UNIF,BASIS[1:Jmodel, ])
#' all.equal(PREDICTORS,PREDICTORS2)        # expansion of coefficients into functions
#'
#' COEF = project(PREDICTORS,BASIS)         # projection back to basis functions
#' max(abs(COEF-UNIF))

project = function(X,basis){
  # projects functions in rows of X onto the basis given by the rows of basis
  if(is.vector(X)) X = matrix(X,nrow=1)
  if(is.vector(basis)) basis = matrix(basis,nrow=1)
  n = nrow(X); d = ncol(X); J = nrow(basis);
  if(ncol(basis)!=d) stop("project: dimension of the functions does not match")
  C = matrix(nrow=n, ncol=J) # matrix of coefficients
  for(i in 1:n) C[i,] = apply(basis,1,function(x) mean(x*X[i,]))
  return(C)
}

#' Basis expansion
#'
#' Expand a set of coefficients into functions in a basis.
#'
#' @param C         a vector of coefficients, or a matrix with one vector per row
#' @param basis     a matrix of basis functions, one function per row
#'
#' @return A matrix of functional values that corresponds to the coefficients given
#' in the rows of \code{C} with respect to the basis in \code{basis}.
#'
#' @examples
#' gridsize = 101                           # grid size
#' Grid = seq(0, 1, length = gridsize)      # grid of measurements
#' n = 150
#' Jmodel = 4                               # number of basis elements
#' BASIS = phif(Jmodel, Grid)               # first Jmodel Fourier basis elements
#' UNIF = matrix(runif(sample.size * Jmodel, min = -1, max = 1), nrow = sample.size, ncol = Jmodel)
#'
#' PREDICTORS = UNIF %*% BASIS[1:Jmodel, ]
#' PREDICTORS2 = expand(UNIF,BASIS[1:Jmodel, ])
#' all.equal(PREDICTORS,PREDICTORS2)        # expansion of coefficients into functions
#'

expand = function(C,basis,na.to.zero=TRUE){
  # expands the coefficient from the rows of C into the basis given by the rows of basis
  if(is.vector(C)) C = matrix(C,nrow=1)
  if(is.vector(basis)) basis = matrix(basis,nrow=1)
  n = nrow(C); J = ncol(C);
  # if(ncol(basis)!=d) stop("expand: dimension of basis functions is not d")
  if(J!=nrow(basis)) stop("expand: dimension of coefficients does not match the number of basis functions")
  if(na.to.zero) C[is.na(C)] = 0
  X = C%*%basis
  return(X)
}

#' Fourier basis functions
#'
#' Creates a matrix of the first few functions from the Fourier basis.
#'
#' @param J Number of basis functions.
#' @param t Vector of the common points in the domain where the basis functions are evaluated.
#'
#' @return A matrix with \code{J} rows. In each row there are functional values of a basis
#' function that correspond to the points in the domain from \code{t}.
#'
#'
#' @examples
#' gridsize = 101                           # grid size
#' J = 4                                    # number of basis elements
#' BASIS = phif(J, seq(0,1,length=gridsize))# first J Fourier basis elements

phif = function(J,t){
  # trigonometric basis of J functions
  # output is matrix of dimensions (J*length(t))
  b = (J-1)/2+1
  B = matrix(nrow=2*b+1,ncol=length(t))
  B[1,] = 1
  for(j in 1:b){
    B[2+2*(j-1),] = sqrt(2)*sin(2*pi*j*t)
    B[3+2*(j-1),] = sqrt(2)*cos(2*pi*j*t)
  }
  return(B[1:J,])
}

# #' B-spline basis functions
# #'
# #' Creates a matrix of the first few functions from the B-spline basis without knots.
# #'
# #' @param J Number of basis functions.
# #' @param t Vector of the common points in the domain where the basis functions are evaluated.
# #'
# #' @return A matrix with \code{J} rows. In each row there are functional values of a basis
# #' function that correspond to the points in the domain from \code{t}.
# #'
# #'
# #' @examples
# #' gridsize = 101                           # grid size
# #' J = 4                                    # number of basis elements
# #' BASIS = phib(Jmodel, Grid)               # first J basis elements
#
# phib = function(J,t) t(bs(t,df=J,intercept=TRUE))
# # B-spline basis of J functions, without knots, matrix of dimensions (J*length(t))

#' \code{L2}-metric
#'
#' Fast computation of the \code{L2}-metric between two sets of functional data.
#'
#' @param A A matrix of functional values, one function per row, \code{n} rows.
#' @param B A matrix of functional values, one function per row, \code{m} rows.
#' @param correct Logical; should the boundary points be computed only by a half of their
#' value due to boundary effects?
#'
#' @return A matrix of size \code{n}-times-\code{m} that contains approximations to the
#' \code{L2}-distances between function that corrspond to the rows of \code{A} and \code{B}.
#' The functions must be evaluated at an equidistant grid. It may be necessary to multiply
#' by a constant that corresponds to the grid size.
#'
#'
#' @examples
#' gridsize = 101                           # grid size
#' J = 4                                    # number of basis elements
#' BASIS = phif(J, seq(0,1,length=gridsize))
#' L2metric(BASIS, BASIS)
#' L2metric(BASIS, BASIS, correct = FALSE)
#' sqrt(crossprod(BASIS[1,]-BASIS[2,]))
#'

L2metric = function(A,B,correct=TRUE){
  # computes fast approximation of L2 distance between fctions A and B
  if(correct){
    M = .Fortran("metrl2",
                 as.numeric(A),
                 as.numeric(B),
                 as.integer(m<-nrow(A)),
                 as.integer(n<-nrow(B)),
                 as.integer(d<-length(as.numeric(A))/nrow(A)),
                 m = as.numeric(rep(-1,m*n)))$m
  } else {
    M = .Fortran("metrl2b",
                 as.numeric(A),
                 as.numeric(B),
                 as.integer(m<-nrow(A)),
                 as.integer(n<-nrow(B)),
                 as.integer(d<-length(as.numeric(A))/nrow(A)),
                 m = as.numeric(rep(-1,m*n)))$m
  }
  return(M = matrix(M,nrow=m))
}

MuellerYao = function(C, Cnew, Y){
  # additive functional derivative estimation (Mueller and Yao ,2010)
  # library(locpol)
  ksi = C # t(t(C) - c(project(colMeans(X),phi)))
  nbasis = ncol(C)
  g = f = matrix(NA,nrow(Cnew),nbasis)
  bwd = rep(NA,nbasis)
  for(k in 1:nbasis){
    # regression estimation
    bw.CV0 <- suppressWarnings(regCVBwSelC(ksi[,k], Y-mean(Y), deg=1, kernel=EpaK, interval=c(0,diff(range(ksi[,k])))))
    fit = locpol(Yc~ksi,data = data.frame(ksi=ksi[,k],Yc = Y-mean(Y)), deg=1, xeval=Cnew[,k], kernel = EpaK, bw=bw.CV0)
    f[,k] = fit$lpFit[rank(Cnew[,k]),2]
    # derivative estimation
    bw.CV <- suppressWarnings(regCVBwSelC(ksi[,k], Y-mean(Y), deg=2, kernel=EpaK, interval=c(0,diff(range(ksi[,k])))))
    fit = locpol(Yc~ksi,data = data.frame(ksi=ksi[,k],Yc = Y-mean(Y)), deg=2, xeval=Cnew[,k], kernel = EpaK, bw=bw.CV)
    g[,k] = fit$lpFit[rank(Cnew[,k]),3]
    bwd[k] = bw.CV
  }
  g[is.na(g)] = 0
  f[is.na(f)] = 0
  return(list(coefficients=g,bwd=bwd,reg.coefficients=f))
}


